<?php
class OverrideTestCase extends OneTestCase
{
    public function testCase($arg = '')
    {
    }
}
